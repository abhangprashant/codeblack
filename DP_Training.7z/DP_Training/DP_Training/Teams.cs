﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP_Training
{
    class Teams
    {
        public Teams(string teamName)
        {
            this.teamName = teamName;

        }
        private string teamName;
        private IPlayerRecord[] playersName;
        private string Coach; // supporting members here


    }

    
}
