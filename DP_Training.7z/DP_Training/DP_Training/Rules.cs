﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP_Training
{
    class Rules
    {
        // Match draw rule
        // Tie result rule
        // Third umpire calling rule
        // No ball Rule
        // Wide ball rule
        
    }
}
