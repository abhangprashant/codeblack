﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP_Training
{
    class Score
    {
        public int GetOver()
        {
            return 100;
        }

        public int GetRun()
        {
            return 100;
        }

        public int GetWicket()
        {
            return 100;
        }

    }
}
